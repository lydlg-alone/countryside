package org.village.common;

public final class AppConstants {
    private AppConstants() {}

    public static final String APP_NAME = "Village 管理系统";
}
