version https://git-lfs.github.com/spec/v1
oid sha256:23410d57be10b904bb131f93d293d1e9c0e79fd4e7b69797c77429ef70018233
size 2462
