version https://git-lfs.github.com/spec/v1
oid sha256:3b59807fed795c58728d0a9d3d81dc2341a8a385e1800bc1058a6847a0114e1a
size 2403
