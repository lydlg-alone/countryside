version https://git-lfs.github.com/spec/v1
oid sha256:a3284eea056d581d7c1d2a3084accdfe86b109c1075b50a1f2b1c65428a72d79
size 3143
