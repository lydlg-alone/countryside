version https://git-lfs.github.com/spec/v1
oid sha256:ca17aeaf87d3fc2fe04b994462d6d893cd3d6fa5efcbb80558f7acb4092131c3
size 6277
