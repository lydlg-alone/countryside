version https://git-lfs.github.com/spec/v1
oid sha256:44939c6fed90afc28aec39398a7dbeb576df3349a24c8435bea7727890d20c27
size 2604
