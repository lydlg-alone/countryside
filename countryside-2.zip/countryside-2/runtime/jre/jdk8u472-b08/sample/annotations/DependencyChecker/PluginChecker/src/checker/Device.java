version https://git-lfs.github.com/spec/v1
oid sha256:9bdc3bc6e27a5fb9c598ca11bb536f06af1fd2fa4151856fea85d1898e27dc21
size 2624
