version https://git-lfs.github.com/spec/v1
oid sha256:d22ec72b66a89c95a82b9a1db8261a45b487de2a7e673f72454b55e2d63a21e2
size 5092
