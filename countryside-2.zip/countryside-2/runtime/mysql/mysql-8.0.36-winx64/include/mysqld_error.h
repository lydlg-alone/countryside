version https://git-lfs.github.com/spec/v1
oid sha256:e6597f42240a28eca6ca58c857ffd13d2c002a380122d25282083e06201d0fc1
size 267876
